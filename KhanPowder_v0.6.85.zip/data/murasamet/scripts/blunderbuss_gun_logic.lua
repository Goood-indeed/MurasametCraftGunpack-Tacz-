local M = {}
--实现扳机延迟
function M.shoot(api)
    api:safeAsyncTask(function ()
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        return false
    end,1.6*1000,0,1)
end
--好像....就可以了？
return M