local M = {}

function M.shoot(api)
    local shoot_delay = api:getScriptParams().shoot_delay * 1000
    api:safeAsyncTask(function ()
        api:shootOnce(true)
        return false
    end,shoot_delay,0,1)
end


return M